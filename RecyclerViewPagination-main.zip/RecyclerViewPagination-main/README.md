# Pagination in Recycler View Using Retrofit Library
 After Scrolling 20 items then load next 20 item.

![Capture1](https://user-images.githubusercontent.com/43530217/119251429-44611b00-bbc8-11eb-9cfe-4cce79470228.PNG)
