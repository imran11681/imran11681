package com.datasysbd.recyclerviewpagination;

public class ModelData {

   private String name,image;

    public String getName() {
        return name;
    }

    public ModelData setName(String name) {
        this.name = name;
        return this;
    }

    public String getImage() {
        return image;
    }

    public ModelData setImage(String image) {
        this.image = image;
        return this;
    }
}
